﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorldApp;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            HelloWordApp app = new HelloWordApp();
            app.RunApp();

        }
    }
}
