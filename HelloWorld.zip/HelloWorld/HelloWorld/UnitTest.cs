﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld
{
        [TestClass]
        public class UnitTest1
        {
            [TestMethod]
            public void TestMethod1()
            {
            }
        }

}
