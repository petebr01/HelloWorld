﻿using HelloWorldApp;
using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloWordApp app = new HelloWordApp();
            app.RunApp();

            Console.WriteLine("Press Enter");
            Console.ReadLine();
        }
    }
}