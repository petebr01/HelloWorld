﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld
{
    public interface IHelloWorld
    {
        string DisplayHelloWorld();
    }
}
