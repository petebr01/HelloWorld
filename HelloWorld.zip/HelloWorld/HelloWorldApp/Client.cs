﻿using System;

namespace HelloWorldApp
{
    public class Client
    {
        private IHelloWorld _helloWorld = null;

        public Client(IHelloWorld helloWld)
        {
            _helloWorld = helloWld;
        }

        public void DoSomeKindOfService()
        {
           Console.WriteLine( _helloWorld.DisplayHelloWorld());
        }
    }
}
