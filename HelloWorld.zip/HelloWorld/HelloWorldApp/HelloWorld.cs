﻿using System;
using System.Collections.Generic;
using System.Text;


namespace HelloWorldApp
{
    public class HelloWorld : IHelloWorld
    {
        public HelloWorld()
        {
        
        }
        public string DisplayHelloWorld()
        {
            return "Hello World";
        }
    }
}
