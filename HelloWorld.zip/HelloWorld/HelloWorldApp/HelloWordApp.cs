﻿using System;

namespace HelloWorldApp
{
    public class HelloWordApp
    {

        //What should go inside this assembly is another class to reference an App.Config file.  However my version of VS 2017 community will
        //does not give me the option to add an App.Config file.  This is to address the configuration requirement.  Using SOLID principals, 
        //A AppSetting class would read the app settings out of the App.Config file.  This AppSetting class would be injected into the HelloWorld
        //class using DI.  Then HelloWorld would reference the AppSetting method telling it where to write "Hello World"

        public void RunApp()
        {
            // A simple DI example.  I didn't want to include external assemblies.  An example would be ninject.
            Client client = new Client(new HelloWorld());
            client.DoSomeKindOfService();

        }
    }
}
