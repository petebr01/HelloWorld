﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldApp
{
    public interface IHelloWorld
    {
        string DisplayHelloWorld();
    }
}
